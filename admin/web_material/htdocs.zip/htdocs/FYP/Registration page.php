<?php
$server = "localhost";
$username = "root" ;
$password = "" ;
$dbname = "fyp data entry table" ;


$conn = mysqli_connect($server , $username , $password , $dbname) ;

if(isset($POST['submit'])){

   if(!isset($POST['name']) && !isset($POST['email']) !isset($POST['withmask']) !isset($POST['withoutmask'])){
    
    $name = $_POST['name'] ;
    $email = $_POST['email'] ;
    $withmask = $_POST['withmask'] ;
    $withoutmask = $_POST['withoutmask'] ;

    $query = "inset into form(name,email,with mask,without mask) values('$name' , '$email' , '$withmask' , '$withoutmask')" ;
    $run = mysqli_query($conn,$query) or die(mysqli_error());

    if($run){
        echo "form submitted successfully" ;
    }
    else {
        echo "form not submitted" ;
    }
    else{
        echo "all fields required" ;
    }
  }
}

?>