<!DOCTYPE html>
<html data-wf-domain="registration-209689.webflow.io" data-wf-page="619f15488bd4835e48439652" data-wf-site="619f15488bd483ae72439651" data-wf-status="1">
    <head>
        <title>registration</title>
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <link href="style.css" rel="stylesheet" type="text/css"/>
        
    </head>
    <body>
        <div class="container w-container">
            <div>
                <div class="w-form">
                    <form id="email-form" name="email-form" data-name="Email Form">
                        <h1 class="heading">
                            صارف کی تفصیلات درج کریں۔<br/>
                        </h1>
                        <input type="text" class="text-field w-input" maxlength="256" name="name" data-name="Name" placeholder="Name" id="name"/>
                        <input type="text" class="text-field-2 w-input" maxlength="256" name="email" data-name="Arid_No" placeholder="Arid_No" id="Arid_No" required=""/>
                        <input type="text" class="text-field-3 w-input" maxlength="256" name="email-3" data-name="Class" placeholder="Class" id="class" required=""/>
                        <input type="file" class="text-field-4 w-input" maxlength="256" name="email-2" data-name="Image_with_mask" placeholder="Image_with_mask" id="Image_with_mask" required=""/>
                        <input type="file" class="text-field-4 w-input" maxlength="256" name="email-2" data-name="Image_without_mask" placeholder="Image_without_mask" id="Image_without_mask" required=""/><br>
                        <input type="submit" value="Submit" data-wait="Please wait..." class="submit-button w-button"/>
                    </form>
                    
                </div>
            </div>
        </div>
    
    </body>
</html>
